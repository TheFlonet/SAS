package businesslogic;

public class UseCaseLogicException extends Exception {
    public UseCaseLogicException() {
        super();
    }

    public UseCaseLogicException(String s) {
        super(s);
    }
}
