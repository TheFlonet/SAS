package businesslogic;

public class UnavailableCookException extends Exception{

}
