package businesslogic.shift;

public enum Type {
    PREPARATORY,
    SERVICE,
    EMPTY
}
